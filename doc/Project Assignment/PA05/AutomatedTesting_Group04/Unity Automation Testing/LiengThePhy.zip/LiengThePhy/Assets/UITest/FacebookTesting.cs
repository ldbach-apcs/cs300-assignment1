﻿using UnityEngine;
using System.Collections;
using NUnit.Framework;
using UnityEngine.TestTools;

public class FacebookTesting : UITest
{



	[UnityTest]
	public IEnumerator ShareTesting()//check share
	{
		yield return LoadScene("FBTesting");

		yield return WaitFor(new ObjectAppeared<FBScript>());
		yield return Press("btnShare");

	}
	[UnityTest]
	public IEnumerator LoginTesting()//check login
	{
		yield return LoadScene("FBTesting");

		yield return WaitFor(new ObjectAppeared<FBScript>());
		yield return Press("btnLogin");

	}
}

